public class Room {
	
	private String name;
	private int capacity;
	private boolean isEmpty;
	
	public Room(String name, int capacity) {
		
		this.capacity = capacity;
		this.name = name;
		isEmpty = true;
	}
	
	public String getName() {
		
		return name;
	}
	
	public int getCapacity() {
		
		return capacity;
	}
	
	public boolean isEmpty() {
		
		return isEmpty;
	}
	
	public void setEmpty(boolean isEmpty) {
		
		this.isEmpty = isEmpty;
	}
	
	
}