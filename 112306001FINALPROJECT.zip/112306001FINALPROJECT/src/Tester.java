import java.util.Scanner;

public class Tester {
	
		public static void printInfo() {
		
			System.out.println("\n請選擇操作:");
			System.out.println("1. 操作完成，返回選擇地點頁面");
			System.out.println("2. 選擇座位");
			System.out.println("3. 退出座位");
		}
	
	    public static void main(String[] args) 
	    {
	    	Seats place1=new Seats("狗洞",5,5);
	    	Seats place2=new Seats("萊爾富前",5,4);
	    	Restaurant place3 = new Restaurant("集英樓", 8, 6);
			Restaurant place4 = new Restaurant("安九食堂", 5, 7);
			Library place5 = new Library("總圖", 9, 7);
			Library place6 = new Library("達賢", 6, 6);
	    	Room roomA = new Room("集思小間A", 6);
	    	Room roomB = new Room("集思小間B", 10);
	    	Room room1 = new Room("討論室1", 4);
	    	Room room2 = new Room("討論室2", 4);
	    	Room room3 = new Room("討論室3", 6);
	    	place5.setRooms(roomA);
	    	place5.setRooms(roomB);
	    	place6.setRooms(room1);
	    	place6.setRooms(room2);
	    	place6.setRooms(room3);
	    	int i;
	    	
	        while (true) 
	        {
	        	i = 0;
	        	System.out.println("\n請選擇地點:");
	        	System.out.println("1. " + place1.getName());
	            System.out.println("2. " + place2.getName());
	            System.out.println("3. " + place3.getName());
	            System.out.println("4. " + place4.getName());
	            System.out.println("5. " + place5.getName());
	            System.out.println("6. " + place6.getName());
	            System.out.println("7. 使用完畢，退出程式");
	            
	            Scanner scanner = new Scanner(System.in);
	            int firstChoice=scanner.nextInt();          
	            
	            	            
	            switch (firstChoice) 
	            {
	            case 1:
	            	place1.initializeSeats();
	            	while(i==0)
	            	{
	            		place1.display();
	            		printInfo();
		                
		                int choice = scanner.nextInt();
		
		                switch (choice) 
		                {
	                    	case 1:
	                    		i=1;
	                    		break;
		                    case 2:
		                    	place1.selectSeat();
		                        break;
		                    case 3:
		                    	place1.cancleSeat();
		                    	break;

		                    default:
		                        System.out.println("無效的選擇，請重新輸入。");
		                }
	            	}
	                break;
	            case 2:
	            	place2.initializeSeats();
	            	while(i==0)
	            	{
	            		place2.display();
	            		printInfo();
		                
		                int choice = scanner.nextInt();
		
		                switch (choice) 
		                {
	                    	case 1:
	                    		i=1;
	                    		break;
		                    case 2:
		                    	place2.selectSeat();
		                        break;
		                    case 3:
		                    	place2.cancleSeat();
		                    	break;
		                    default:
		                        System.out.println("無效的選擇，請重新輸入。");
		                }
	            	}
	                break;
	            case 3:
	            	place3.initializeSeats();
	            	while(i==0)
	            	{
	            		place3.display();
	            		printInfo();
	            		System.out.println("4. 訂位入座");
		                
		                int choice = scanner.nextInt();
		
		                switch (choice) 
		                {
	                    	case 1:
	                    		i=1;
	                    		break;
		                    case 2:
		                    	place3.selectSeat();
		                        break;
		                    case 3:
		                    	place3.cancleSeat();
		                    	break;
		                    case 4:
		                    	place3.checkIn();
		                    	break;
		                    default:
		                        System.out.println("無效的選擇，請重新輸入。");
		                }
	            	}
	                break;
	            case 4:
	            	place4.initializeSeats();
	            	while(i==0)
	            	{
	            		place4.display();
	            		printInfo();
	            		System.out.println("4. 訂位入座");
		                
		                int choice = scanner.nextInt();
		
		                switch (choice) 
		                {
	                    	case 1:
	                    		i=1;
	                    		break;
		                    case 2:
		                    	place4.selectSeat();
		                        break;
		                    case 3:
		                    	place4.cancleSeat();
		                    	break;
		                    case 4:
		                    	place4.checkIn();
		                    	break;
		                    default:
		                        System.out.println("無效的選擇，請重新輸入。");
		                }
	            	}
	                break;
	            case 5:
	            	place5.initializeSeats();
	            	while(i==0)
	            	{
	            		place5.display();
	            		printInfo();
	            		System.out.println("4. 登記討論室");
	            		System.out.println("5. 指定討論室");
	            		System.out.println("6. 離開討論室");
	            		
		                int choice = scanner.nextInt();
		
		                switch (choice) 
		                {
	                    	case 1:
	                    		i=1;
	                    		break;
		                    case 2:
		                    	place5.selectSeat();
		                        break;
		                    case 3:
		                    	place5.cancleSeat();
		                    	break;
		                    case 4:
		                    	System.out.println("請填寫人數");
		                        int number1 = scanner.nextInt();
		                    	place5.checkIn(number1);
		                    	break;
		                    case 5:
		                    	System.out.println("請輸入討論室代碼\n(格式: 代碼[1/2]))");
		                        short number2 = scanner.nextShort();
		                        place5.checkIn(number2);
		                    	break;
		                    case 6:
		                    	System.out.println("請輸入討論室代碼\n(格式: 代碼[1/2]))");
		                        int number3 = scanner.nextShort();
		                        place5.leave(number3);
		                    	break;
		                    default:
		                        System.out.println("無效的選擇，請重新輸入。");
		                }
	            	}
	                break;
	            case 6:
	            	place6.initializeSeats();
	            	while(i==0)
	            	{
	            		place6.display();
	            		printInfo();
	            		System.out.println("4. 登記討論室");
	            		System.out.println("5. 指定討論室");
	            		System.out.println("6. 離開討論室");
	            		
		                int choice = scanner.nextInt();
		
		                switch (choice) 
		                {
	                    	case 1:
	                    		i=1;
	                    		break;
		                    case 2:
		                    	place6.selectSeat();
		                        break;
		                    case 3:
		                    	place6.cancleSeat();
		                    	break;
		                    case 4:
		                    	System.out.println("請填寫人數");
		                        int number1 = scanner.nextInt();
		                    	place6.checkIn(number1);
		                    	break;
		                    case 5:
		                    	System.out.println("請輸入討論室代碼\n(格式: 代碼[1/2/3]))");
		                        short number2 = scanner.nextShort();
		                        place6.checkIn(number2);
		                    	break;
		                    case 6:
		                    	System.out.println("請輸入討論室代碼\n(格式: 代碼[1/2/3]))");
		                        int number3 = scanner.nextShort();
		                        place6.leave(number3);
		                    	break;
		                    default:
		                        System.out.println("無效的選擇，請重新輸入。");
		                }
	            	}
	                break;
	            case 7:
	                System.out.println("感謝使用，退出程式。");
	                System.exit(0);
	            default:
	                System.out.println("無效的選擇，請重新輸入。");
            }
            
        }
    }
}