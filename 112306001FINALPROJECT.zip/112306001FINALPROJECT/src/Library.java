import java.util.ArrayList;
public class Library extends Seats {
	
	private ArrayList<Room> rooms;
	
	public Library(String name, int row, int col) {
		
		super(name, row, col);
		rooms = new ArrayList<Room>();
	}
	
	public ArrayList<Room> getRooms() {
		
		return rooms;
	}
	
	public void setRooms(Room room) {
		
		rooms.add(room);
	}
	
	public void display() //overrides
	{
    	System.out.println("\n座位表 - " + getName() + ":");
        for (int i = 0; i < seat.length; i++) {
            for (int j = 0; j < seat[0].length; j++) {
                System.out.print(seat[i][j] + " ");
            }
            System.out.println();
        }
        
        System.out.print(getName() + "討論室一覽表: ");
        for(Room room : rooms) {
        	System.out.print(room.getName());
        	if(room.isEmpty()) 
        		
        		System.out.print("(空) ");
        	else
        		
        		System.out.print("(滿) ");
        }
        System.out.println();
    }
	
	public void checkIn(int number)
	{
		for(Room room:rooms) {
			
			if(number <= room.getCapacity() && room.isEmpty()) {
				
				System.out.println("已成功為您登記" + room.getName());
				room.setEmpty(false);
				break;
			}
			else if(number > room.getCapacity())
				System.out.println("登記失敗，" + room.getName() + "只能容納" + room.getCapacity() + "人。");
			else
				System.out.println("登記失敗，" + room.getName() + "已有人使用。");
		}
	}
	
	public void checkIn(short number) //overload
	{
		Room room = rooms.get(number - 1);
		if(number <= room.getCapacity() && room.isEmpty()) {
			
			System.out.println("已成功為您登記" + room.getName());
			room.setEmpty(false);
		}
		else if(number > room.getCapacity())
			
			System.out.println("登記失敗，" + room.getName() + "只能容納" + room.getCapacity() + "人。");
		else
			
			System.out.println("登記失敗，" + room.getName() + "已有人使用。");
		
	}
	
	public void leave(int number) { 
		
		Room room = rooms.get(number - 1);
		room.setEmpty(true);
		System.out.println("使用完畢，已成功退出討論室" + room.getName() + "，歡迎下次再來");
	}

}
