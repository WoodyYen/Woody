import java.util.Scanner;  //我改了seat[]的名字，還有我改了[][]從private到protected

public class Seats extends Place
{
	protected static char[][] seat ;
	
	public Seats(String name,int row,int col)
	{
		super(name,row,col);
	}
	
	public void initializeSeats() {
        seat = new char[super.getRow()][super.getCol()];

        for (int i = 0; i < super.getRow(); i++) {
            for (int j = 0; j < super.getCol(); j++) {
                seat[i][j] = 'O'; // 'O' 表示座位是空的
            }
        }
    }

    public void display() {
    	System.out.println("\n座位表 - " + super.getName() + ":");
        for (int i = 0; i < seat.length; i++) {
            for (int j = 0; j < seat[0].length; j++) {
                System.out.print(seat[i][j] + " ");
            }
            System.out.println();
        }
    }

    public void selectSeat() 
    {
        System.out.println("請輸入欲選擇的座位位置 (格式: 行 列): ");
        Scanner scanner = new Scanner(System.in);
        int col = scanner.nextInt()-1;
        int row = scanner.nextInt()-1;

        if (isValidSeat(row, col)) 
        {
            if(seat[row][col] == 'O')
            {
	        	seat[row][col] = 'X'; // 'X' 表示座位已被選擇
	            System.out.println("成功選擇座位！");
            }
            else
            {
            	System.out.println("該座位已被選擇，請重新選擇。");
            }
        } 
        else 
        {
            System.out.println("無效的座位，請重新選擇。");
        }
    }
    
    public void cancleSeat()
    {
    	System.out.println("請輸入欲選擇退出的座位位置 (格式: 行 列): ");
        Scanner scanner = new Scanner(System.in);
        int col = scanner.nextInt()-1;
        int row = scanner.nextInt()-1;

        if (isValidSeat(row, col)) 
        {
            if(seat[row][col] == 'X')
            {
	        	seat[row][col] = 'O'; // 'X' 表示座位已被選擇
	            System.out.println("成功退出座位！");
            }
            else
            {
            	System.out.println("該座位沒被選擇，請重新選擇。");
            }
        } 
        else 
        {
            System.out.println("無效的座位，請重新選擇。");
        }
    }

    public static boolean isValidSeat(int row, int col) {
        return row >= 0 && row < seat.length && col >= 0 && col < seat[0].length;
    }

   
}