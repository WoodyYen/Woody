import java.util.Scanner;

public class Restaurant extends Seats {
	
	public Restaurant(String name, int row, int col) {
		
		super(name, row, col);
	}
	
    public void selectSeat()  //overrides
    {
        System.out.println("請輸入欲選擇的座位位置 (格式: 行 列): ");
        Scanner scanner = new Scanner(System.in);
        int col = scanner.nextInt() - 1;
        int row = scanner.nextInt() - 1;

        if (isValidSeat(row, col)) 
        {
            if(seat[row][col] == 'O')
            {
	        	seat[row][col] = '△'; // '△' 表示座位正處於訂位狀態
	            System.out.println("成功訂位！請記得盡速來到現場，否則您的訂位將被取消");
            }
            else if(seat[row][col] == '△')
            {
            	System.out.println("該座位已被預訂，請重新選擇。");
            }	
            else
            {
            	System.out.println("該座位已被選擇，請重新選擇。");
        	}
        } 
        else 
        {
            System.out.println("無效的座位，請重新選擇。");
        }
        
    }
    
    public void cancleSeat() //overrides
    {
    	System.out.println("請輸入欲選擇退出的座位位置 (格式: 行 列): ");
        Scanner scanner = new Scanner(System.in);
        int col = scanner.nextInt()-1;
        int row = scanner.nextInt()-1;

        if (isValidSeat(row, col)) 
        {
            if(seat[row][col] == 'X' ||seat[row][col] == '△')
            {
	        	seat[row][col] = 'O'; 
	            System.out.println("成功退出座位！");
            }
            else
            {
            	System.out.println("該座位沒被選擇，請重新選擇。");
            }
        } 
        else 
        {
            System.out.println("無效的座位，請重新選擇。");
        }
    }
    
    public void checkIn() 
    {
    	System.out.println("請輸入您事前預訂的訂位位置 (格式: 行 列): ");
        Scanner scanner = new Scanner(System.in);
        int col = scanner.nextInt()-1;
        int row = scanner.nextInt()-1;

        if (isValidSeat(row, col)) 
        {
            if(seat[row][col] == '△')
            {
	        	seat[row][col] = 'X'; 
	            System.out.println("成功報到！歡迎入座！");
            }
            else
            {
            	System.out.println("該座位沒被訂位，請重新選擇。");
            }
        } 
        else 
        {
            System.out.println("無效的座位，請重新選擇。");
        }
    }

}
